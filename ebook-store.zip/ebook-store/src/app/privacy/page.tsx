export default function PrivacyPage() {
  return (
    <main className="max-w-2xl mx-auto px-6 py-16 text-neutral-200 bg-neutral-950 min-h-screen">
      <h1 className="text-3xl font-semibold mb-8">Privacy Policy</h1>

      <Section title="What we collect">
        Your email address (only when you make a purchase, to deliver your ebook),
        and anonymous page-view data (which pages get visited — no email or
        personal identifier attached to this).
      </Section>

      <Section title="Who can see your email">
        Only the site administrator. Purchase emails are shown in the admin
        dashboard for 30 days after purchase, then hidden from that view. The
        underlying order record is kept longer, as required for accounting and
        tax purposes, but is not displayed in the day-to-day admin view after
        that window.
      </Section>

      <Section title="What we don't do">
        We don't sell or share your email with advertisers or third parties.
      </Section>

      <Section title="Cookies">
        We use a minimal cookie/local-storage flag to remember that you've seen
        the cookie notice, and anonymous analytics to understand site traffic.
      </Section>

      <Section title="Your rights">
        You can request that we delete your order record or stop holding your
        email by contacting the site owner directly.
      </Section>

      <p className="text-sm text-neutral-500 mt-12">
        This is a starting template, not legal advice — for real customers,
        have this reviewed against GDPR/CCPA requirements for your region.
      </p>
    </main>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-8">
      <h2 className="text-lg font-medium mb-2">{title}</h2>
      <p className="text-neutral-400 leading-relaxed">{children}</p>
    </section>
  );
}
