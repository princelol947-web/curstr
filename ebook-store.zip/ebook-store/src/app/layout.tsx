import "./globals.css";
import CookieConsent from "@/components/CookieConsent";

export const metadata = {
  title: "Ebook Store",
  description: "Independently published ebooks, sold directly by the author.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        {children}
        <CookieConsent />
      </body>
    </html>
  );
}
