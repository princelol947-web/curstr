export default function RefundPolicyPage() {
  return (
    <main className="max-w-2xl mx-auto px-6 py-16 text-neutral-200 bg-neutral-950 min-h-screen">
      <h1 className="text-3xl font-semibold mb-8">Refund Policy</h1>
      <p className="text-neutral-400 leading-relaxed mb-6">
        Because ebooks are delivered instantly as digital files, all sales are
        generally final once the download link has been sent. If you were
        charged in error, received a corrupted file, or the wrong title, contact
        us within 7 days of purchase and we'll make it right.
      </p>
      <p className="text-sm text-neutral-500">
        Adjust this to match your actual policy and local consumer-protection
        law before launch — some regions require a cooling-off period even for
        digital goods.
      </p>
    </main>
  );
}
