import { NextRequest, NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";
import { prisma } from "@/lib/prisma";
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(req: NextRequest) {
  const body = await req.text();
  const sig = req.headers.get("stripe-signature") as string;

  let event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET as string);
  } catch (err) {
    console.error("Webhook signature verification failed", err);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as any;

    const order = await prisma.order.update({
      where: { stripeSessionId: session.id },
      data: { status: "paid" },
      include: { ebook: true },
    });

    // Deliver the real download link only now, post-payment, via email —
    // never expose fileUrl through any public API route.
    await resend.emails.send({
      from: "orders@yourdomain.com",
      to: order.buyerEmail,
      subject: `Your copy of "${order.ebook.title}"`,
      html: `<p>Thanks for your purchase! Download it here:</p>
             <p><a href="${order.ebook.fileUrl}">${order.ebook.title}</a></p>
             <p>This link is personal to your order — please don't share it.</p>`,
    });
  }

  return NextResponse.json({ received: true });
}
