import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// No email, no cookie ID, no IP stored — this is aggregate traffic data only,
// separate from the Order table that holds actual buyer information.
export async function POST(req: NextRequest) {
  const { ebookId, path, eventType } = await req.json();
  await prisma.pageView.create({
    data: { ebookId: ebookId || null, path, eventType: eventType || "view" },
  });
  return NextResponse.json({ ok: true });
}
