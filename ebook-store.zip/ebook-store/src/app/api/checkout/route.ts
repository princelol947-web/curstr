import { NextRequest, NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  try {
    const { ebookId, buyerEmail } = await req.json();

    if (!ebookId || !buyerEmail) {
      return NextResponse.json({ error: "Missing ebookId or buyerEmail" }, { status: 400 });
    }

    const ebook = await prisma.ebook.findUnique({ where: { id: ebookId } });
    if (!ebook) {
      return NextResponse.json({ error: "Ebook not found" }, { status: 404 });
    }

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      customer_email: buyerEmail,
      line_items: [
        {
          price_data: {
            currency: ebook.currency,
            product_data: { name: ebook.title },
            unit_amount: ebook.priceCents,
          },
          quantity: 1,
        },
      ],
      success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/ebooks/${ebook.slug}`,
    });

    // Record as "pending" — flipped to "paid" only by the webhook once
    // Stripe confirms payment. The download link is never issued from here.
    await prisma.order.create({
      data: {
        buyerEmail,
        ebookId,
        amountCents: ebook.priceCents,
        currency: ebook.currency,
        stripeSessionId: session.id,
        status: "pending",
      },
    });

    return NextResponse.json({ url: session.url });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Checkout failed" }, { status: 500 });
  }
}
