import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any)?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);

  const [views, orders] = await Promise.all([
    prisma.pageView.findMany({ where: { createdAt: { gte: ninetyDaysAgo } } }),
    prisma.order.findMany({
      where: { status: "paid", createdAt: { gte: ninetyDaysAgo } },
      include: { ebook: { select: { title: true } } },
    }),
  ]);

  // Group views + purchases by day, for a daily traffic-vs-conversion chart
  const byDay: Record<string, { day: string; views: number; buyers: number }> = {};
  for (const v of views) {
    const day = v.createdAt.toISOString().slice(0, 10);
    byDay[day] ??= { day, views: 0, buyers: 0 };
    byDay[day].views += 1;
  }
  for (const o of orders) {
    const day = o.createdAt.toISOString().slice(0, 10);
    byDay[day] ??= { day, views: 0, buyers: 0 };
    byDay[day].buyers += 1;
  }

  // Distribution of purchases by hour of day — "most buyers buy at ___"
  const byHour = Array.from({ length: 24 }, (_, h) => ({ hour: h, purchases: 0 }));
  for (const o of orders) {
    byHour[o.createdAt.getHours()].purchases += 1;
  }
  const peakHour = byHour.reduce((a, b) => (b.purchases > a.purchases ? b : a), byHour[0]);

  // Revenue and unit sales per title
  const perTitle: Record<string, { title: string; sales: number; revenueCents: number }> = {};
  for (const o of orders) {
    const t = o.ebook.title;
    perTitle[t] ??= { title: t, sales: 0, revenueCents: 0 };
    perTitle[t].sales += 1;
    perTitle[t].revenueCents += o.amountCents;
  }

  return NextResponse.json({
    daily: Object.values(byDay).sort((a, b) => a.day.localeCompare(b.day)),
    hourly: byHour,
    peakHour: peakHour.hour,
    topEbooks: Object.values(perTitle).sort((a, b) => b.sales - a.sales),
    totals: { views: views.length, buyers: orders.length },
  });
}
