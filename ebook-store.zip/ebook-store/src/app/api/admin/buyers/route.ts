import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any)?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

  // The 30-day cutoff is a UI/product policy, applied here at query time.
  // It limits what the admin dashboard SHOWS — it does not delete or
  // truncate the underlying Order records, which stay intact for
  // accounting/tax purposes indefinitely (or per your retention policy).
  const buyers = await prisma.order.findMany({
    where: { status: "paid", createdAt: { gte: thirtyDaysAgo } },
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      buyerEmail: true,
      amountCents: true,
      currency: true,
      createdAt: true,
      ebook: { select: { title: true } },
    },
  });

  return NextResponse.json({ buyers, windowDays: 30 });
}
