export default function TermsPage() {
  return (
    <main className="max-w-2xl mx-auto px-6 py-16 text-neutral-200 bg-neutral-950 min-h-screen">
      <h1 className="text-3xl font-semibold mb-8">Terms &amp; Conditions</h1>

      <Section title="1. Who runs this site">
        This store is operated and sold by a single independent seller. All ebooks
        listed here are sold directly by that seller; there is no other vendor or
        reseller on this platform.
      </Section>

      <Section title="2. Purchases">
        When you buy an ebook, you're purchasing a personal, non-transferable license
        to read it. You may not resell, redistribute, or publicly share the file.
      </Section>

      <Section title="3. Delivery">
        Your download link is sent to the email address you provide at checkout,
        after payment is confirmed. Please double-check your email address before
        paying — we can't guarantee redelivery to a different address.
      </Section>

      <Section title="4. Refunds">
        See our separate Refund Policy for details on when refunds are available.
      </Section>

      <Section title="5. Changes to these terms">
        These terms may be updated from time to time. Continued use of the site
        after changes means you accept the new terms.
      </Section>

      <p className="text-sm text-neutral-500 mt-12">
        This is a starting template, not legal advice — have a lawyer review it
        before you rely on it for a real store.
      </p>
    </main>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-8">
      <h2 className="text-lg font-medium mb-2">{title}</h2>
      <p className="text-neutral-400 leading-relaxed">{children}</p>
    </section>
  );
}
