"use client";
import { useEffect, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";

type Buyer = {
  id: string;
  buyerEmail: string;
  amountCents: number;
  currency: string;
  createdAt: string;
  ebook: { title: string };
};

type Analytics = {
  daily: { day: string; views: number; buyers: number }[];
  hourly: { hour: number; purchases: number }[];
  peakHour: number;
  topEbooks: { title: string; sales: number; revenueCents: number }[];
  totals: { views: number; buyers: number };
};

export default function AdminDashboard() {
  const [buyers, setBuyers] = useState<Buyer[]>([]);
  const [analytics, setAnalytics] = useState<Analytics | null>(null);

  useEffect(() => {
    fetch("/api/admin/buyers").then((r) => r.json()).then((d) => setBuyers(d.buyers ?? []));
    fetch("/api/admin/analytics").then((r) => r.json()).then(setAnalytics);
  }, []);

  return (
    <div className="space-y-10 max-w-6xl mx-auto">
      {/* Summary */}
      {analytics && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <Stat label="Views (90d)" value={analytics.totals.views} />
          <Stat label="Buyers (90d)" value={analytics.totals.buyers} />
          <Stat label="Peak buying hour" value={`${analytics.peakHour}:00`} />
          <Stat label="Buyers shown (30d)" value={buyers.length} />
        </div>
      )}

      {/* Views vs buyers over time */}
      {analytics && (
        <section>
          <h2 className="text-sm uppercase tracking-wide text-neutral-400 mb-3">
            Views vs. buyers
          </h2>
          <div className="h-64 bg-neutral-900 rounded-lg p-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={analytics.daily}>
                <CartesianGrid stroke="#262626" />
                <XAxis dataKey="day" stroke="#737373" fontSize={12} />
                <YAxis stroke="#737373" fontSize={12} />
                <Tooltip contentStyle={{ background: "#171717", border: "1px solid #333" }} />
                <Line type="monotone" dataKey="views" stroke="#a3a3a3" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="buyers" stroke="#f59e0b" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>
      )}

      {/* Purchase time distribution */}
      {analytics && (
        <section>
          <h2 className="text-sm uppercase tracking-wide text-neutral-400 mb-3">
            When buyers purchase (by hour)
          </h2>
          <div className="h-56 bg-neutral-900 rounded-lg p-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics.hourly}>
                <CartesianGrid stroke="#262626" />
                <XAxis dataKey="hour" stroke="#737373" fontSize={12} />
                <YAxis stroke="#737373" fontSize={12} />
                <Tooltip contentStyle={{ background: "#171717", border: "1px solid #333" }} />
                <Bar dataKey="purchases" fill="#f59e0b" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>
      )}

      {/* Buyers table — 30-day window only */}
      <section>
        <h2 className="text-sm uppercase tracking-wide text-neutral-400 mb-3">
          Buyers (last 30 days only)
        </h2>
        <div className="bg-neutral-900 rounded-lg overflow-hidden">
          <table className="w-full text-sm">
            <thead className="text-neutral-400 text-left border-b border-neutral-800">
              <tr>
                <th className="px-4 py-2">Email</th>
                <th className="px-4 py-2">Ebook</th>
                <th className="px-4 py-2">Amount</th>
                <th className="px-4 py-2">Date</th>
              </tr>
            </thead>
            <tbody>
              {buyers.map((b) => (
                <tr key={b.id} className="border-b border-neutral-800/50">
                  <td className="px-4 py-2">{b.buyerEmail}</td>
                  <td className="px-4 py-2">{b.ebook.title}</td>
                  <td className="px-4 py-2">
                    {(b.amountCents / 100).toFixed(2)} {b.currency.toUpperCase()}
                  </td>
                  <td className="px-4 py-2 text-neutral-400">
                    {new Date(b.createdAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
              {buyers.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-4 py-6 text-center text-neutral-500">
                    No purchases in the last 30 days.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <p className="text-xs text-neutral-500 mt-2">
          Buyer emails older than 30 days are hidden from this view. Full order records are
          retained separately for accounting purposes.
        </p>
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="bg-neutral-900 rounded-lg p-4">
      <div className="text-2xl font-semibold">{value}</div>
      <div className="text-xs text-neutral-400 mt-1">{label}</div>
    </div>
  );
}
