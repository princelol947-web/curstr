"use client";
import { useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";

// 3D canvas is client-only and can be heavy — load it lazily
const Scene3D = dynamic(() => import("@/components/Scene3D"), { ssr: false });

export default function HomePage() {
  const [scrollProgress, setScrollProgress] = useState(0);
  const [reducedMotion, setReducedMotion] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReducedMotion(mq.matches);

    function onScroll() {
      if (!heroRef.current) return;
      const rect = heroRef.current.getBoundingClientRect();
      const total = rect.height + window.innerHeight;
      const progress = Math.min(Math.max((window.innerHeight - rect.top) / total, 0), 1);
      setScrollProgress(progress);
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <main className="bg-neutral-950 text-neutral-100 min-h-screen">
      <section ref={heroRef} className="h-[130vh] relative">
        <div className="sticky top-0 h-screen grid grid-cols-1 md:grid-cols-2 items-center px-6 md:px-16 gap-8">
          <div>
            <p className="text-amber-500 text-sm tracking-widest uppercase mb-4">Ebooks</p>
            <h1 className="text-4xl md:text-6xl font-semibold leading-tight">
              Read something worth
              <br /> finishing.
            </h1>
            <p className="mt-6 text-neutral-400 max-w-md">
              Independently written, sold directly by the author. No middleman,
              no distributor markup — every copy comes straight from here.
            </p>
            <a
              href="/ebooks"
              className="inline-block mt-8 bg-amber-500 text-neutral-950 font-medium px-6 py-3 rounded-md hover:bg-amber-400 transition"
            >
              Browse ebooks
            </a>
          </div>
          <div className="h-[50vh] md:h-[70vh]">
            {!reducedMotion ? (
              <Scene3D scrollProgress={scrollProgress} />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-neutral-600 text-sm">
                (3D animation paused — reduced motion preferred)
              </div>
            )}
          </div>
        </div>
      </section>

      <footer className="px-6 md:px-16 py-10 border-t border-neutral-900 text-sm text-neutral-500 flex flex-wrap gap-6">
        <a href="/terms" className="hover:text-neutral-300">Terms &amp; Conditions</a>
        <a href="/privacy" className="hover:text-neutral-300">Privacy Policy</a>
        <a href="/refund-policy" className="hover:text-neutral-300">Refund Policy</a>
      </footer>
    </main>
  );
}
