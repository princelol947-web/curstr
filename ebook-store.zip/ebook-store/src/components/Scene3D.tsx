"use client";
import { useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Float, Environment } from "@react-three/drei";
import * as THREE from "three";

// A floating "book" (a simple extruded box standing in for a real ebook
// cover) that rotates as the page scrolls and pulses when clicked.
function FloatingBook({ scrollProgress, clicked }: { scrollProgress: number; clicked: boolean }) {
  const mesh = useRef<THREE.Mesh>(null);
  const targetScale = useRef(1);

  useFrame((_, delta) => {
    if (!mesh.current) return;
    // Scroll drives rotation — this is the "3D animation when we scroll" ask
    mesh.current.rotation.y = scrollProgress * Math.PI * 2;
    mesh.current.rotation.x = Math.sin(scrollProgress * Math.PI) * 0.3;

    // Click drives a brief scale pulse
    targetScale.current = clicked ? 1.15 : 1;
    mesh.current.scale.lerp(
      new THREE.Vector3(targetScale.current, targetScale.current, targetScale.current),
      delta * 6
    );
  });

  return (
    <mesh ref={mesh}>
      <boxGeometry args={[1.4, 2, 0.15]} />
      <meshStandardMaterial color="#f59e0b" metalness={0.3} roughness={0.35} />
    </mesh>
  );
}

export default function Scene3D({ scrollProgress }: { scrollProgress: number }) {
  const [clicked, setClicked] = useState(false);

  return (
    <div
      className="w-full h-full cursor-pointer"
      onClick={() => {
        setClicked(true);
        setTimeout(() => setClicked(false), 250);
      }}
    >
      <Canvas camera={{ position: [0, 0, 4.5], fov: 45 }}>
        <ambientLight intensity={0.6} />
        <directionalLight position={[3, 3, 3]} intensity={1.2} />
        <Float speed={1.5} rotationIntensity={0.2} floatIntensity={0.6}>
          <FloatingBook scrollProgress={scrollProgress} clicked={clicked} />
        </Float>
        <Environment preset="city" />
      </Canvas>
    </div>
  );
}
