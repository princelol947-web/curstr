"use client";
import { useEffect, useState } from "react";

export default function CookieConsent() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!localStorage.getItem("cookie-consent")) setVisible(true);
  }, []);

  function accept() {
    localStorage.setItem("cookie-consent", "accepted");
    setVisible(false);
  }

  if (!visible) return null;

  return (
    <div className="fixed bottom-0 inset-x-0 bg-neutral-900 border-t border-neutral-800 text-neutral-200 px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4 z-50">
      <p className="text-sm max-w-2xl">
        This site uses basic analytics to see which pages get visited and stores your
        email if you make a purchase, so we can deliver your ebook. See our{" "}
        <a href="/privacy" className="underline">Privacy Policy</a>.
      </p>
      <button
        onClick={accept}
        className="shrink-0 bg-amber-500 text-neutral-950 font-medium px-4 py-2 rounded-md hover:bg-amber-400 transition"
      >
        Got it
      </button>
    </div>
  );
}
