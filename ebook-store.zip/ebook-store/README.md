# Ebook Store

A responsive (desktop + mobile) storefront for selling ebooks, built with
Next.js. Includes:

- A scroll-and-click-reactive 3D hero animation (React Three Fiber)
- Stripe Checkout, with the download link only released after payment is confirmed
- A single hard-coded admin account (yours) — no other admin can be created
- An admin dashboard showing buyers from the **last 30 days only**, plus
  analytics (views vs. buyers over time, peak purchase hour, top titles)
- Terms & Conditions, Privacy Policy, Refund Policy, and a cookie consent banner

## 1. Install

```bash
npm install
```

## 2. Set up your database

You need a PostgreSQL database (Supabase, Railway, Neon, or your own server
all work). Copy `.env.example` to `.env` and fill in `DATABASE_URL`.

```bash
npx prisma migrate dev --name init
```

## 3. Create your admin login

You are the only admin, ever — there's no signup form. Generate a password
hash and put your Gmail + the hash in `.env`:

```bash
node -e "console.log(require('bcryptjs').hashSync('yourpassword', 10))"
```

Set `ADMIN_EMAIL` to your Gmail address and `ADMIN_PASSWORD_HASH` to the output.

## 4. Set up Stripe

1. Create a Stripe account, grab your secret key into `STRIPE_SECRET_KEY`.
2. Add a webhook endpoint pointing at `/api/webhooks/stripe`, listening for
   `checkout.session.completed`. Put its signing secret in `STRIPE_WEBHOOK_SECRET`.

## 5. Set up email delivery

Sign up for [Resend](https://resend.com) (or swap in SendGrid/Postmark) and
put your API key in `RESEND_API_KEY`. This is what actually emails the buyer
their download link after payment.

## 6. Add your ebooks

Add rows to the `Ebook` table (via Prisma Studio: `npx prisma studio`, or a
small seed script) with title, price, cover image URL, and a **private**
file URL (e.g. a signed S3 URL) that customers never see directly — it's
only sent by email after payment confirms.

## 7. Run locally

```bash
npm run dev
```

Visit `/` for the storefront and `/admin/login` to sign in as admin.

## 8. Deploy

Deploy to Vercel (or any Node host). Set all the same environment variables
there. Point your Stripe webhook at the production URL.

## Notes on the buyer-visibility rule

The admin dashboard only *displays* buyer emails from orders placed in the
last 30 days (`/api/admin/buyers`). Older orders still exist in the database
— most countries require you to keep transaction records for several years
for tax purposes — they're just filtered out of that view. If you want a
different cutoff, change the `30 * 24 * 60 * 60 * 1000` value in
`src/app/api/admin/buyers/route.ts`.

## Legal disclaimer

The Terms, Privacy Policy, and Refund Policy pages are starting templates,
not legal advice. Have them reviewed for your country's consumer protection,
tax, and data privacy laws (e.g. GDPR/CCPA) before taking real payments.
